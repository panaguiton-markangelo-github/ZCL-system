<svg
    {{ $attributes }}
    viewBox="0 0 40 40"
>
<img width="100" alt="Seal of Zamboanga City" src="https://upload.wikimedia.org/wikipedia/commons/4/4a/Seal_of_Zamboanga_City.png">
</svg>


