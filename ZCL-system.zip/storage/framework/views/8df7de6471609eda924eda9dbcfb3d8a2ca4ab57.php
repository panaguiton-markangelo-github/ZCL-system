<?php echo e($slot); ?>

<?php /**PATH C:\Users\drene\Documents\Laravel9_project\ZC-library\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>