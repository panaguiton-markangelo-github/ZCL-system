<?php if (isset($component)) { $__componentOriginaleb9364b2ce9f5237293f3d9e317474cc3f61288e = $component; } ?>
<?php $component = App\View\Components\ClibrarianLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('clibrarian-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ClibrarianLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__('Dashboard')); ?>

            </h2>

            
            
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <?php echo e(__("Welcome Catalog Librarian ")); ?> <?php echo e(Auth::guard('librarians')->user()->firstName); ?> <?php echo e(Auth::guard('librarians')->user()->lastName); ?>

        <?php echo e(__("!")); ?>

    </div>

    <br>
    
    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1 grid grid-cols-2 gap-2">
        
        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg  text-center w-3/4">
                <i class="fa-solid fa-users text-2xl"></i>
                <h5 class="text-md leading-tight font-medium mb-2"> 
                     Total users:
                </h5>
                <p class="text-base mb-4">

                <?php if($allUsers->count() == 0): ?>
                    There are currently no registered users.
                <?php endif; ?>

                <?php if($allUsers->count() == 1): ?>
                    There is currently <?php echo e($allUsers->count()); ?> registered user.
                <?php endif; ?>

                <?php if($allUsers->count() > 1): ?>
                    There are currently <?php echo e($allUsers->count()); ?> registered users.
                <?php endif; ?>
                
                </p>

            </div>
        </div>

        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg text-center w-3/4">
                <i class="fa-solid fa-book text-2xl"></i>
                <h5 class=" text-md leading-tight font-medium mb-2 "> 
                     Total books:
                </h5>
                <p class=" text-base mb-4">
                    <?php if($allBooks->count() == 0): ?>
                        There are currently no registered books.
                    <?php endif; ?>

                    <?php if($allBooks->count() == 1): ?>
                        There is currently <?php echo e($allBooks->count()); ?> registered book.
                    <?php endif; ?>

                    <?php if($allBooks->count() > 1): ?>
                        There are currently <?php echo e($allBooks->count()); ?> registered books..
                    <?php endif; ?>
                </p>

            </div>
        </div>
    
    </div>

    <br>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <div class="tem-grid">
            <div class="registered_users">
                <div class="card">
                    <div class="card-header">
                        <h3>Books</h3>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'success','href' => ''.e(route('catalog_librarian.view.books')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','href' => ''.e(route('catalog_librarian.view.books')).'']); ?>
                            <span><?php echo e(__('See all')); ?></span>
                            <i class="fa-solid fa-arrow-right ml-2"></i>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                    </div>
                    
                    <div class="card-body">
                        <div class="table-responsive-cus">
                            <table width="100%">
                                <thead>
                                    <tr>
                                        
                                        <td>No.</td>
                                        <td> Title </td>
                                        <td> Author </td>
                                        <td> Published </td>
                                        <td> Collection </td>
                                        <td> Status </td>                                 
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        
                                        <td> <?php echo e($loop->iteration); ?> </td>
                                        <td> <?php echo e($book->title); ?> </td>
                                        <td> <?php echo e($book->author); ?> </td>
                                        <td> <?php echo e($book->published); ?> </td>
                                        <td> <?php echo e($book->collection); ?> </td>
                                        <td> <?php echo e($book->status); ?> </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb9364b2ce9f5237293f3d9e317474cc3f61288e)): ?>
<?php $component = $__componentOriginaleb9364b2ce9f5237293f3d9e317474cc3f61288e; ?>
<?php unset($__componentOriginaleb9364b2ce9f5237293f3d9e317474cc3f61288e); ?>
<?php endif; ?>

<style>
    .tem-grid {
        display: grid;
        grid-gap: 2rem;
        grid-template-columns: 100%;
    }
    
    .card {
        border-radius:5px
    }
    
    .card-header
    {
        padding: 1rem;
    }
    
    .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #f0f0f0;
    }
    
    .card-header h3{
        font-size: 1.2rem;
    }
    
    .card-header a {
        border-radius:10px;
        font-size: .8rem;
        padding: .5rem 1rem;
        text-decoration: none;
    }
    
    .card-body a {
        border-radius:10px;
        font-size: 1.1rem;
        padding: .3rem .8rem;
        text-decoration: none;
    }
    
    .card-body button {
        border-radius:10px;
        font-size: 1.1rem;
        padding: .3rem .8rem;
        text-decoration: none;
    }
    
    table {
        border-collapse: collapse;
    }
    
    thead tr {
        border-top: 1px solid #f0f0f0;
        border-bottom: 1px solid #f0f0f0;
    }
    
    thead td {
        font-weight: 700;
    }
    
    td {
        padding: .5rem 1rem;
        font-size: .9rem;
       
    }
    
    td .status {
        display: inline-block;
        height: 10px;
        width: 10px;
        border-radius: 50%;
        margin-right: 1rem;
    }
    
    td button {
        border-radius:8px;
        font-size: 1rem;
        padding: .3rem .7rem;
        text-decoration: none;
    }
</style>
<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/catalog_librarian/dashboard_catalog_librarian.blade.php ENDPATH**/ ?>