<?php echo e($slot); ?>

<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>