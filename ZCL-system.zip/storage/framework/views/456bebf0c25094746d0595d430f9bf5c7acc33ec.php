<?php if (isset($component)) { $__componentOriginal49832d77c192f71290736dce7e97696b24cee783 = $component; } ?>
<?php $component = App\View\Components\BlibrarianLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('blibrarian-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BlibrarianLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__("Borrower's Card Application")); ?>

            </h2>

        

        </div>
     <?php $__env->endSlot(); ?>

   

    <div class="p-6 mt-2 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
    
        <?php if(session('message')): ?> 
            <p
                x-data="{ show: true }"
                x-show="show"
                x-transition
                x-init="setTimeout(() => show = false, 2500)"
                class="text-sm text-green-600 dark:text-green-400 mb-2"
            >
                <?php echo e(__(session('message'))); ?>

            </p>
        <?php endif; ?>

        <?php if($errors->any()): ?>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p
                x-data="{ show: true }"
                x-show="show"
                x-transition
                x-init="setTimeout(() => show = false, 2500)"
                class="text-sm text-red-600 dark:text-red-400 mb-2"
            >
                <?php echo e($error); ?>

            </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?> 

        <div class="overflow-x-auto">
            <table id="table" class="min-w-full">
                <thead>
                    <tr>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">No.</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">Request Date</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">Borrower's Firstname</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">Borrower's Lastname</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">ID card</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">Status</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left"></th>
                    </tr>

                    <tr>
                        <th scope="col" class="text-sm font-medium   dark:text-gray-900 px-6 py-4 text-left"></th>
                        <th scope="col" class="text-sm font-medium   dark:text-gray-900 px-6 py-4 text-left select_search">Request Date</th>
                        <th scope="col" class="text-sm font-medium   dark:text-gray-900 px-6 py-4 text-left"></th>
                        <th scope="col" class="text-sm font-medium   dark:text-gray-900 px-6 py-4 text-left"></th>
                        <th scope="col" class="text-sm font-medium   dark:text-gray-900 px-6 py-4 text-left select_search">ID card</th>
                        <th scope="col" class="text-sm font-medium   dark:text-gray-900 px-6 py-4 text-left select_search">Status</th>
                        <th scope="col" class="text-sm font-medium   dark:text-gray-900 px-6 py-4 text-left"></th>  
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__currentLoopData = $borrowers_app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($borrower->created_at); ?></td>
                            <td><?php echo e($borrower->firstName); ?></td>
                            <td><?php echo e($borrower->lastName); ?></td>
                            <td><?php echo e($borrower->id_card); ?></td>
                            <?php if($borrower->status == 'PENDING'): ?>
                                <td class="text-yellow-500 dark:text-yellow-400"><?php echo e($borrower->status); ?></td>
                            <?php endif; ?>
                            <?php if($borrower->status == 'APPROVED'): ?>
                                <td class="text-green-500 dark:text-green-400"><?php echo e($borrower->status); ?></td>
                            <?php endif; ?>
                            <?php if($borrower->status == 'DECLINED'): ?>
                                <td class="text-red-500 dark:text-red-400"><?php echo e($borrower->status); ?></td>
                            <?php endif; ?>

                            <td>
                            
                                <div class="sm:rounded-lg">
                                    <div class="max-w-xl">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'success','href' => '/borrowing_librarian/application/borrower/'.e($borrower->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','href' => '/borrowing_librarian/application/borrower/'.e($borrower->id).'']); ?>
                                            <i class="fa-solid fa-circle-info"></i>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                    
                                    </div>
                                </div>  
                        
                            </td> 
 
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                </tbody>
                <tfoot>
                    <tr>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">No.</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">Request Date</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">Borrower's Firstname</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">Borrower's Lastname</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">ID card</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left">Status</th>
                        <th scope="col" class="text-sm font-medium   px-6 py-4 text-left"></th>
                        
                    </tr>
                </tfoot>
            </table>
        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script>
           $(document).ready(function () {
                $('#table').DataTable({
                    initComplete: function () {
                        this.api()
                            .columns()
                            .every(function () {
                                var column = this;
                                if ($(column.header()).hasClass('select_search')) {

                                var select = $('<select><option value=""></option></select>')
                                    .appendTo($(column.header()).empty())
                                    .on('change', function () {
                                        var val = $.fn.dataTable.util.escapeRegex(
                                            $(this).val()
                                        );
                                        column
                                            .search(val ? '^' + val + '$' : '', true, false)
                                            .draw();
                                    });
                                column.data().unique().sort().each(function (d, j) {
                                    select.append('<option value="' + d + '">' + d + '</option>')
                                });

                            }
                            });
                    },
                });
            });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49832d77c192f71290736dce7e97696b24cee783)): ?>
<?php $component = $__componentOriginal49832d77c192f71290736dce7e97696b24cee783; ?>
<?php unset($__componentOriginal49832d77c192f71290736dce7e97696b24cee783); ?>
<?php endif; ?>

<style>
    .dataTables_wrapper .dataTables_length select {
        padding-right: 25px;
        font-weight: 900;
        background-color: #9d4edd;
        color: white;
    }
    tfoot input {
        width: 100%;
        padding: 3px;
        box-sizing: border-box;
    }
</style>

<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/borrowing_librarian/borrower_card_app.blade.php ENDPATH**/ ?>