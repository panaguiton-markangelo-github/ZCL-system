<div id="kustomer">
    <kustomer
        :params="<?php echo e(json_encode(config('kustomer'))); ?>"
        :labels="<?php echo e(json_encode(trans('kustomer::kustomer'))); ?>"
    ></kustomer>
</div>
<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/vendor/kustomer/kustomer.blade.php ENDPATH**/ ?>