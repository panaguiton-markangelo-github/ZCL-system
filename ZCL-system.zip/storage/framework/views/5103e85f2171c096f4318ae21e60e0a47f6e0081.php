<footer class="flex-shrink-0 px-6 py-4">
    <p class="flex items-center justify-center gap-1 text-sm text-gray-600 dark:text-gray-400">
        © All rights reserved 2022-2023
    </p>
</footer>
<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/components/hlib/footer.blade.php ENDPATH**/ ?>