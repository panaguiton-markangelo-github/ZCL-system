<?php if (isset($component)) { $__componentOriginal373f847efe2d4746c8474fe5c27cab2319699c7a = $component; } ?>
<?php $component = App\View\Components\HlibrarianLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hlibrarian-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HlibrarianLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__('Dashboard')); ?>

            </h2>

            
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <?php echo e(__("Welcome Head Librarian ")); ?> <?php echo e(Auth::guard('librarians')->user()->firstName); ?> <?php echo e(Auth::guard('librarians')->user()->lastName); ?>

        <?php echo e(__("!")); ?>


    </div>

    <br>


    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1 grid grid-cols-2 gap-1">

        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg  w-1/2">
                <h5 class=" text-xl leading-tight font-medium mb-2 text-center"> 
                    <i class="fa-solid fa-calendar text-2xl"></i> Total events
                </h5>
                <p class=" text-base mb-4">
                    <?php if($events == 0): ?>
                        There are currently no events.
                    <?php endif; ?>

                    <?php if($events == 1): ?>
                        There is currently <?php echo e($events); ?> event.
                    <?php endif; ?>

                    <?php if($events > 1): ?>
                        There are currently <?php echo e($events); ?> events.
                    <?php endif; ?>
                </p>

            </div>
        </div>

        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg  w-1/2">
                <h5 class="text-xl leading-tight font-medium mb-2 text-center"> 
                    <i class="fa-solid fa-bullhorn text-2xl"></i> Total announcements 
                </h5>
                <p class=" text-base mb-4">
                    <?php if($announcements == 0): ?>
                    There are currently no announcements.
                    <?php endif; ?>

                    <?php if($announcements == 1): ?>
                        There is currently <?php echo e($announcements); ?> announcement.
                    <?php endif; ?>

                    <?php if($announcements > 1): ?>
                        There are currently <?php echo e($announcements); ?> announcements.
                    <?php endif; ?>
                </p>

            </div>
        </div>

        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg  w-1/2">
                
                <h5 class="text-xl leading-tight font-medium mb-2 text-center"> 
                    <i class="fa-solid fa-users text-2xl"></i> Total users 
                </h5>
                <p class="text-base mb-4">

                <?php if($users == 0): ?>
                    There are currently no registered users.
                <?php endif; ?>

                <?php if($users == 1): ?>
                    There is currently <?php echo e($users); ?> registered user.
                <?php endif; ?>

                <?php if($users > 1): ?>
                    There are currently <?php echo e($users); ?> registered users.
                <?php endif; ?>
                
                </p>

            </div>
        </div>

        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg  w-1/2">
                <h5 class=" text-xl leading-tight font-medium mb-2 text-center"> 
                    <i class="fa-solid fa-book text-2xl"></i> Total books
                </h5>
                <p class=" text-base mb-4">
                    <?php if($books == 0): ?>
                        There are currently no registered books.
                    <?php endif; ?>

                    <?php if($books == 1): ?>
                        There is currently <?php echo e($books); ?> registered book.
                    <?php endif; ?>

                    <?php if($books > 1): ?>
                        There are currently <?php echo e($books); ?> registered books..
                    <?php endif; ?>
                </p>

            </div>
        </div>
       
        
          
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal373f847efe2d4746c8474fe5c27cab2319699c7a)): ?>
<?php $component = $__componentOriginal373f847efe2d4746c8474fe5c27cab2319699c7a; ?>
<?php unset($__componentOriginal373f847efe2d4746c8474fe5c27cab2319699c7a); ?>
<?php endif; ?>

<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/head_librarian/dashboard_head_librarian.blade.php ENDPATH**/ ?>