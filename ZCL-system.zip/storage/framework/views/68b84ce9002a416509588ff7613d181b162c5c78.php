<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__("Book's Details for")); ?> <?php echo e($book->title); ?>

            </h2>


        </div>
     <?php $__env->endSlot(); ?>


    <div class="p-6 mt-2 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1" >
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'danger','href' => ''.e(route('dashboard')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'danger','href' => ''.e(route('dashboard')).'']); ?>
            <span><?php echo e(__('Go Back')); ?></span>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="p-6 mt-2 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <p class="mt-1 text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Book Details')); ?>

        </p>

        <br>
        <hr>

        <br>

        <div class="flex justify-center">
            <img class="border-solid border-4 border-red-500" src="<?php echo e(asset('storage/'.$book->image)); ?>" alt="none" width="300" height="300">
        </div>

        <br>

        <div class="grid grid-cols-4 gap-4 text-center">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('Title: ')); ?> 
                </p>

                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e($book->title); ?> 
                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('Author: ')); ?>  
                </p>

                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e($book->author); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('Published: ')); ?> 
                </p>

                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e($book->published); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('Subject: ')); ?>

                </p>

                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e($book->subject); ?> 
                </p>

            </div>
        </div>

        <br>

        <div class="grid grid-cols-2 gap-2 text-center">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('Publisher: ')); ?>

                </p>

                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e($book->publisher); ?> 
                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('ISBN: ')); ?>

                </p>

                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e($book->isbn); ?> 
                </p>

            </div>
        </div>

        <br>

        <p class="mt-1 text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Summary')); ?>

        </p>

        <br>
        <hr>
        
        <div>
            <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                <?php echo e(__('Summary: ')); ?>

            </p>

            <p class="mt-2 text-md text-gray-600 dark:text-gray-400" >
                <?php echo e($book->summary); ?> 
            </p>

        </div>

        <br>

        <p class="mt-1 text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Book Location')); ?>

        </p>

        <br>
        <hr>

        <div class="grid grid-cols-3 gap-3 text-center">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('Collection: ')); ?>  
                </p>

                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e($book->collection); ?>

                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('Shelf Location: ')); ?>

                </p>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e($book->shelf_location); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400" style="font-weight: 900">
                    <?php echo e(__('Status: ')); ?>

                </p>

                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                     <?php echo e($book->status); ?> 
                </p>

            </div>
        </div>

        <br>
        <br>
        <hr> 
        <br>

        <?php if($cart->where('id', $book->id)->count()): ?>
            <div class="text-center" >
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('This book is already on your basket.')); ?>

                </p>
            </div>
        <?php else: ?>
        <div>
            <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($book->id); ?>" name="book_id">
                <input type="number" value="1" name="quantity" hidden>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'success','class' => 'justify-center w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','class' => 'justify-center w-full']); ?>
                    <i class="fa-solid fa-cart-plus mx-2"></i>
                    <span><?php echo e(__('Add to basket')); ?></span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </form>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script>
           $(document).ready(function () {
                $('#table').DataTable({
                responsive: true,
                scrollX: true
            });
            });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<style>
    tfoot input {
        width: 100%;
        padding: 3px;
        box-sizing: border-box;
    }
</style>

<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/book_view.blade.php ENDPATH**/ ?>