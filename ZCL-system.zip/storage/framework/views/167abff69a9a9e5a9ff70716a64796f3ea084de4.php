<?php if (isset($component)) { $__componentOriginal49832d77c192f71290736dce7e97696b24cee783 = $component; } ?>
<?php $component = App\View\Components\BlibrarianLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('blibrarian-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BlibrarianLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__("Information for this application")); ?>

            </h2>

        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="p-6 mt-2 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">

        <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Borrower Card Application Information')); ?> (Request Status: <?php echo e($borrowers_app[0]->status); ?>)
        </p>

        <p class="mt-1 font-bold text-md text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Request Date: ')); ?> <?php echo e($borrowers_app[0]->created_at); ?>

        </p>

        <br>
        <hr>
        <br>
        
        <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Borrower Card Application Information')); ?>

        </p>

        <br>
        <hr>

        <div class="grid grid-cols-4 gap-4 text-center">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('First Name: ')); ?> <?php echo e($borrowers_app[0]->firstName); ?> 
                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Last Name: ')); ?> <?php echo e($borrowers_app[0]->lastName); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Email: ')); ?> <?php echo e($borrowers_app[0]->email); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Phone: ')); ?> <?php echo e($borrowers_app[0]->phone); ?> 
                </p>

            </div>

           
        </div>

        <br>

        <div class="grid grid-cols-4 gap-4 text-center">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Address: ')); ?> <?php echo e($borrowers_app[0]->address); ?> 
                </p>
            </div>
            
            <div>
                <?php if($borrowers_app[0]->type == '0'): ?>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Borrower Type: ')); ?> <?php echo e(__('NON-LGU')); ?> 
                    </p>
                <?php endif; ?>

                <?php if($borrowers_app[0]->type == '1'): ?>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Borrower Type: ')); ?> <?php echo e(__('LGU')); ?> 
                    </p>
                 <?php endif; ?>

                 <?php if($borrowers_app[0]->type == '2'): ?>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Borrower Type: ')); ?> <?php echo e(__('RECOMMENDED')); ?> 
                    </p>
                 <?php endif; ?>
               

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('ID card: ')); ?> <?php echo e($borrowers_app[0]->id_card); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Status: ')); ?> <?php echo e($borrowers_app[0]->status); ?> 
                </p>

            </div>

           
        </div>

        <?php if($is_prof->count()): ?>

            <br>

            <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
                <?php echo e(__('Profession Information')); ?>

            </p>
    
            <br>
            <hr>

            <div class="grid grid-cols-4 gap-4 text-center">

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Position: ')); ?> <?php echo e($is_prof[0]->position); ?> 
                    </p>
                </div>
                
                <div>
                
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Office: ')); ?>  <?php echo e($is_prof[0]->office); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Office Address: ')); ?> <?php echo e($is_prof[0]->office_address); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Telephone No. (Work): ')); ?> <?php echo e($is_prof[0]->tel_no_work); ?> 
                    </p>
                </div>

            
            </div>

        <?php endif; ?>

        <?php if($is_stud->count()): ?>

            <br>

            <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
                <?php echo e(__('Student Information')); ?>

            </p>
    
            <br>
            <hr>

            <div class="grid grid-cols-4 gap-4 text-center">

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('School: ')); ?> <?php echo e($is_stud[0]->school); ?> 
                    </p>
                </div>
                
                <div>
                
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Out of School: ')); ?>  <?php echo e($is_stud[0]->out_of_school); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('School Level: ')); ?> <?php echo e($is_stud[0]->school_level); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Grade/Year Level: ')); ?> <?php echo e($is_stud[0]->grade_year_level); ?> 
                    </p>
                </div>

            
            </div>

        <?php endif; ?>

        <?php if($is_rec->count()): ?>

            <br>

            <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
                <?php echo e(__('Recommended Information')); ?>

            </p>
    
            <br>
            <hr>

            <div class="grid grid-cols-4 gap-4 text-center">

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Recommended by: ')); ?> <?php echo e($is_rec[0]->rec_by); ?> 
                    </p>
                </div>
                
                <div>
                
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Position: ')); ?>  <?php echo e($is_rec[0]->rec_by_position); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Office: ')); ?> <?php echo e($is_rec[0]->rec_by_office); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Office Address: ')); ?> <?php echo e($is_rec[0]->rec_by_office_address); ?> 
                    </p>
                </div>

            
            </div>

            <br>

            <div class="grid grid-cols-3 gap-3 text-center">

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Home Adress: ')); ?> <?php echo e($is_rec[0]->rec_by_home_address); ?> 
                    </p>
                </div>
                
                <div>
                
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Telephone No. (Work): ')); ?>  <?php echo e($is_rec[0]->rec_by_tel_no_work); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Cellphone No.: ')); ?> <?php echo e($is_rec[0]->rec_by_cel_no); ?> 
                    </p>

                </div>
            
            </div>

        <?php endif; ?>


        
        <!-- Buttons -->
        <div class="mt-6 flex justify-end">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => ''.e(route('borrowing_librarian.borrower_card_app.view')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('borrowing_librarian.borrower_card_app.view')).'']); ?>
                <?php echo e(__('Go Back')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        </div>

        <br>
        <hr>
        <br>

        <?php if($borrowers_app[0]->status == 'PENDING'): ?>
            <div class="grid grid-cols-2 gap-2 text-center">
                    
                
                <div class="sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('borrowing_librarian.partials.approve_borrower', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>   

                <div class="sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('borrowing_librarian.partials.decline_borrower', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>   
                
            </div>
        <?php endif; ?>

        <?php if($borrowers_app[0]->status == 'APPROVED'): ?>
            <div class="flex justify-center text-center">
                     
                <p class="text-sm text-cyan-600 dark:text-cyan-400 text-center font-bold">
                    You have approved this Borrower Card Application.
                </p>
                
            </div>
        <?php endif; ?>

        <?php if($borrowers_app[0]->status == 'DECLINED'): ?>
            <div class="flex justify-center text-center">
                
                <p class="text-sm text-cyan-600 dark:text-cyan-400 text-center font-bold">
                    You have declined this Borrower Card Application.
                </p>

            </div>
        <?php endif; ?>
        

    </div>

   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49832d77c192f71290736dce7e97696b24cee783)): ?>
<?php $component = $__componentOriginal49832d77c192f71290736dce7e97696b24cee783; ?>
<?php unset($__componentOriginal49832d77c192f71290736dce7e97696b24cee783); ?>
<?php endif; ?>



<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/borrowing_librarian/show_borrower_app.blade.php ENDPATH**/ ?>