<?php if (isset($component)) { $__componentOriginaleb9364b2ce9f5237293f3d9e317474cc3f61288e = $component; } ?>
<?php $component = App\View\Components\ClibrarianLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('clibrarian-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ClibrarianLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__("Additional information for")); ?> <?php echo e($book->title); ?>

            </h2>

        </div>
     <?php $__env->endSlot(); ?>

    
    <div class="p-6 mt-2 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">

           
        <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Book Details')); ?>

        </p>

        <br>
        <hr>

        <div>
            <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                <?php echo e(__('Title: ')); ?> <?php echo e($book->title); ?> 
            </p>
        </div>

        <br>

        <div class="grid grid-cols-2 gap-2 text-start">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Author: ')); ?> <?php echo e($book->author); ?> 
                </p>
    
            </div>

            <div class="grid grid-cols-1 gap-1 text-start">
                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Call No: ')); ?> <?php echo e($book->call_no); ?> 
                    </p>
                </div>
                
                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('LC: ')); ?> <?php echo e($book->lc); ?> 
                    </p>
    
                </div>
    
                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('DDC: ')); ?> <?php echo e($book->ddc); ?> 
                    </p>
                </div>

                <div class="grid grid-cols-2 gap-2 text-start">
                    <div>
                        <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                            <?php echo e(__('Author No: ')); ?> <?php echo e($book->author_no); ?> 
                        </p>
    
                    </div>
                    
                    <div>
                        <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                            <?php echo e(__('©: ')); ?> <?php echo e($book->c); ?> 
                        </p>
    
                    </div>
                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Section: ')); ?> <?php echo e($book->section); ?> 
                    </p>
                </div>

            </div>
            
        </div>

        <br>

        <div>
            <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                <?php echo e(__('Published: ')); ?> <?php echo e($book->published); ?> 
            </p>

        </div>

        <br>

        <div class="grid grid-cols-2 gap-2 text-start">

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Place of Pub: ')); ?> <?php echo e($book->place_pub); ?> 
                </p>
            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Publisher: ')); ?> <?php echo e($book->publisher); ?> 
                </p>
            </div>
            
        </div>

        <br>

        <div class="grid grid-cols-2 gap-2 text-start">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Edition/Vol: ')); ?> <?php echo e($book->edition_vol); ?> 
                </p>
    
            </div>
    
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Source: ')); ?> <?php echo e($book->source); ?> 
                </p>
    
            </div>
        </div>

        <br>

        <div class="grid grid-cols-2 gap-2 text-start">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('ISBN: ')); ?> <?php echo e($book->isbn); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Series: ')); ?> <?php echo e($book->series); ?> 
                </p>
            </div>
        </div>
        
        <br>

        <div class="grid grid-cols-2 gap-2 text-start">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Pagination: ')); ?> <?php echo e($book->pagination); ?> 
                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Incls: ')); ?> <?php echo e($book->incls); ?> 
                </p>

            </div>
        </div>

        <br>

        <div class="grid grid-cols-4 gap-4 text-start">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Date Acquired: ')); ?> <?php echo e($book->date_acq); ?> 
                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Property No: ')); ?> <?php echo e($book->property_no); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Acc. No: ')); ?> <?php echo e($book->acc_no); ?> 
                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Amount: ')); ?> <?php echo e($book->amount); ?> 
                </p>

            </div>
        </div>

        <br>

        <div>
            <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                <?php echo e(__('Subject: ')); ?> <?php echo e($book->subject); ?> 
            </p>

        </div>

        <br>

        <hr>
        <br>

        <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Summary')); ?>

        </p>

        <br>
        <hr>
        
        <div>
            <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                <?php echo e(__('Summary: ')); ?> <?php echo e($book->summary); ?> 
            </p>

        </div>

        <br>

        <hr>
        <br>

        <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Book Location')); ?>

        </p>

        <br>
        <hr>

        <div class="grid grid-cols-3 gap-3 text-center">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Collection: ')); ?> <?php echo e($book->collection); ?> 
                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Shelf Location: ')); ?> <?php echo e($book->shelf_location); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Status: ')); ?> <?php echo e($book->status); ?> 
                </p>

            </div>
        </div>


        
    

        <!-- Buttons -->
        <div class="mt-6 flex justify-end">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['href' => ''.e(route('catalog_librarian.view.books')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('catalog_librarian.view.books')).'']); ?>
                <?php echo e(__('Go Back')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        </div>

    </div>

   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb9364b2ce9f5237293f3d9e317474cc3f61288e)): ?>
<?php $component = $__componentOriginaleb9364b2ce9f5237293f3d9e317474cc3f61288e; ?>
<?php unset($__componentOriginaleb9364b2ce9f5237293f3d9e317474cc3f61288e); ?>
<?php endif; ?>



<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/catalog_librarian/show_book.blade.php ENDPATH**/ ?>