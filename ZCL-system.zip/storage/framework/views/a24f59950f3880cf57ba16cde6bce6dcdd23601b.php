<svg
    <?php echo e($attributes); ?>

    viewBox="0 0 40 40"
>
<img width="100" alt="Seal of Zamboanga City" src="https://upload.wikimedia.org/wikipedia/commons/4/4a/Seal_of_Zamboanga_City.png">
</svg>


<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/components/application-logo.blade.php ENDPATH**/ ?>