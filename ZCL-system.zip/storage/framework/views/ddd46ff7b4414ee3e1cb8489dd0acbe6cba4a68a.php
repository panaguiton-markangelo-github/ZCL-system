<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>