<?php if (isset($component)) { $__componentOriginal49832d77c192f71290736dce7e97696b24cee783 = $component; } ?>
<?php $component = App\View\Components\BlibrarianLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('blibrarian-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BlibrarianLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__('Dashboard')); ?>

            </h2>
 
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <?php echo e(__("Welcome Borrowing Librarian ")); ?> <?php echo e(Auth::guard('librarians')->user()->firstName); ?> <?php echo e(Auth::guard('librarians')->user()->lastName); ?>

        <?php echo e(__("!")); ?>

    </div>

    <br>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1 grid grid-cols-3 gap-3">
        
        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg text-center  w-3/4">
                <i class="fa-solid fa-book-open-reader text-2xl"></i>
                <h5 class="text-sm leading-tight font-medium mb-2"> 
                     Books currently borrowed:
                </h5>
                <p class="text-base mb-4">
                   
                <?php if($borrowed_books->count() == 0): ?>
                    There are currently no borrowed books
                <?php endif; ?>

                <?php if($borrowed_books->count() == 1): ?>
                    There is currently <?php echo e($borrowed_books->count()); ?> borrowed book.
                <?php endif; ?>

                <?php if($borrowed_books->count() > 1): ?>
                    There are currently <?php echo e($borrowed_books->count()); ?> borrowed books.
                <?php endif; ?>
                
                </p>

            </div>
        </div>

        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg  text-center w-3/4">
                <i class="fa-solid fa-book text-2xl"></i> 
                <h5 class=" text-sm leading-tight font-medium mb-2">
                    Book/s request/s for borrowing:
                </h5>
                
                <p class=" text-base mb-4">
                
                    <?php if($request_books->count() == 0): ?>
                        There are currently no request.
                    <?php endif; ?>

                    <?php if($request_books->count() == 1): ?>
                        There is currently <?php echo e($request_books->count()); ?> request.
                    <?php endif; ?>

                    <?php if($request_books->count() > 1): ?>
                        There are currently <?php echo e($request_books->count()); ?> requests.
                    <?php endif; ?>
                </p>

            </div>
        </div>

        <div class="flex justify-center">
            <div class="block py-6 px-6 rounded-lg shadow-lg text-center  w-3/4">
                <i class="fa-solid fa-users-rectangle text-2xl"></i>
                <h5 class=" text-sm leading-tight font-medium mb-2 "> 
                    Borrower's card application:
                </h5>
                
                <p class=" text-base mb-4">
                    
                    <?php if($borrowers_app->count() == 0): ?>
                        There are currently no application
                    <?php endif; ?>

                    <?php if($borrowers_app->count()== 1): ?>
                        There is currently <?php echo e($borrowers_app->count()); ?> application.
                    <?php endif; ?>

                    <?php if($borrowers_app->count() > 1): ?>
                        There are currently <?php echo e($borrowers_app->count()); ?> applications.
                    <?php endif; ?>
                </p>

            </div>
        </div>
    
    </div>

    <br>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <div class="tem-grid">
            <div class="books_borrowed">
                <div class="card">
                    <div class="card-header">
                        <h3>Books currently borrowed</h3>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'success','href' => ''.e(route('borrowing_librarian.borrowed_books.view')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','href' => ''.e(route('borrowing_librarian.borrowed_books.view')).'']); ?>
                            <span><?php echo e(__('See all')); ?></span>
                            <i class="fa-solid fa-arrow-right ml-2"></i>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                    </div>
                    
                    <div class="card-body">
                        <div class="table-responsive-cus">
                            <table width="100%">
                                <thead>
                                    <tr>
                                        
                                        <td>No.</td>
                                        <td>Borrowed Date</td>
                                        <td> Title </td>
                                        <td> Author </td>
                                        <td> Published </td>
                                        <td> Collection </td>
                                        <td> Status </td>                                  
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php $__currentLoopData = $borrowed_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        
                                        <td> <?php echo e($loop->iteration); ?> </td>
                                        <td> <?php echo e($book->borrowed_at); ?> </td>
                                        <td> <?php echo e($book->title); ?> </td>
                                        <td> <?php echo e($book->author); ?> </td>
                                        <td> <?php echo e($book->published); ?> </td>
                                        <td> <?php echo e($book->collection); ?> </td>
                                        <td> <?php echo e($book->status); ?> </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="books_requested">
                <div class="card">
                    <div class="card-header">
                        <h3>Book/s request/s for borrowing</h3>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'success','href' => ''.e(route('borrowing_librarian.requested_books.view')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','href' => ''.e(route('borrowing_librarian.requested_books.view')).'']); ?>
                            <span><?php echo e(__('See all')); ?></span>
                            <i class="fa-solid fa-arrow-right ml-2"></i>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive-cus">
                            <table width="100%">
                                <thead>
                                    <tr>
                                        
                                        <td>No.</td>
                                        <td>Request Date</td>
                                        <td> Book Title </td>
                                        <td> Borrower's First Name </td>
                                        <td> Borrower's Last Name </td>   
                                        <td> Status </td>
                                                                   
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php $__currentLoopData = $request_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        
                                        <td> <?php echo e($loop->iteration); ?> </td>
                                        <td> <?php echo e($rbook->created_at); ?> </td>
                                        <td> <?php echo e($rbook->title); ?> </td>
                                        <td> <?php echo e($rbook->firstName); ?> </td>
                                        <td> <?php echo e($rbook->lastName); ?> </td>
                                        <td> <?php echo e($rbook->status); ?> </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="borrowers_card_app">
                <div class="card">
                    <div class="card-header">
                        <h3>Borrower's card application</h3>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'success','href' => ''.e(route('borrowing_librarian.borrower_card_app.view')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','href' => ''.e(route('borrowing_librarian.borrower_card_app.view')).'']); ?>
                            <span><?php echo e(__('See all')); ?></span>
                            <i class="fa-solid fa-arrow-right ml-2"></i>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive-cus">
                            <table width="100%">
                                <thead>
                                    <tr>
                                        
                                        <td>No.</td>
                                        <td>Request Date</td>
                                        <td> Borrower's First Name </td>
                                        <td> Borrower's Last Name </td>  
                                        <td> ID card</td> 
                                        <td> Status </td>                               
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $borrowers_app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rborrower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <tr>
                                        
                                        <td> <?php echo e($loop->iteration); ?> </td>
                                        <td> <?php echo e($rborrower->created_at); ?> </td>
                                        <td> <?php echo e($rborrower->firstName); ?> </td>
                                        <td> <?php echo e($rborrower->lastName); ?> </td>
                                        <td> <?php echo e($rborrower->id_card); ?> </td>
                                        <td> <?php echo e($rborrower->status); ?> </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49832d77c192f71290736dce7e97696b24cee783)): ?>
<?php $component = $__componentOriginal49832d77c192f71290736dce7e97696b24cee783; ?>
<?php unset($__componentOriginal49832d77c192f71290736dce7e97696b24cee783); ?>
<?php endif; ?>

<style>
.tem-grid {
    display: grid;
    grid-gap: 2rem;
    grid-template-columns: 100%;
}

.card {
    border-radius:5px
}

.card-header
{
    padding: 1rem;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #f0f0f0;
}

.card-header h3{
    font-size: 1rem;
}

.card-header a {
    border-radius:10px;
    font-size: .8rem;
    padding: .5rem 1rem;
    text-decoration: none;
}

.card-body a {
    border-radius:10px;
    font-size: 1.1rem;
    padding: .3rem .8rem;
    text-decoration: none;
}

.card-body button {
    border-radius:10px;
    font-size: 1.1rem;
    padding: .3rem .8rem;
    text-decoration: none;
}

table {
    border-collapse: collapse;
}

thead tr {
    border-top: 1px solid #f0f0f0;
    border-bottom: 1px solid #f0f0f0;
}

thead td {
    font-weight: 700;
}

td {
    padding: .5rem 1rem;
    font-size: .9rem;
   
}

td .status {
    display: inline-block;
    height: 10px;
    width: 10px;
    border-radius: 50%;
    margin-right: 1rem;
}

td button {
    border-radius:8px;
    font-size: 1rem;
    padding: .3rem .7rem;
    text-decoration: none;
}
</style><?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/borrowing_librarian/dashboard_borrowing_librarian.blade.php ENDPATH**/ ?>