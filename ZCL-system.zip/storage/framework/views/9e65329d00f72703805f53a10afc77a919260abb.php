<?php if (isset($component)) { $__componentOriginal49832d77c192f71290736dce7e97696b24cee783 = $component; } ?>
<?php $component = App\View\Components\BlibrarianLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('blibrarian-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BlibrarianLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__("Borrowed Books")); ?>

            </h2>

        

        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 mt-2 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
       
        <?php if(session('message')): ?> 
            <p
                x-data="{ show: true }"
                x-show="show"
                x-transition
                x-init="setTimeout(() => show = false, 2500)"
                class="text-sm text-green-600 dark:text-green-400 mb-2"
            >
                <?php echo e(__(session('message'))); ?>

            </p>
        <?php endif; ?>

        <?php if($errors->any()): ?>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p
                x-data="{ show: true }"
                x-show="show"
                x-transition
                x-init="setTimeout(() => show = false, 2500)"
                class="text-sm text-red-600 dark:text-red-400 mb-2"
            >
                <?php echo e($error); ?>

            </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
        
        <div class="overflow-x-auto" >
            <table id="table" class="min-w-full">
                <thead>
                    <tr>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">No.</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Borrowed Date</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Title</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Author</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Published</th>  
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">collection</th>       
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Status</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left"></th>
                    </tr>

                    <tr>
                        <th scope="col" class="text-sm font-medium  dark:text-gray-900 px-6 py-4 text-left"></th>
                        <th scope="col" class="text-sm font-medium  dark:text-gray-900 px-6 py-4 text-left select_search">Borrowed Date</th>
                        <th scope="col" class="text-sm font-medium  dark:text-gray-900 px-6 py-4 text-left"></th>
                        <th scope="col" class="text-sm font-medium  dark:text-gray-900 px-6 py-4 text-left"></th>
                        <th scope="col" class="text-sm font-medium  dark:text-gray-900 px-6 py-4 text-left select_search">Published</th>  
                        <th scope="col" class="text-sm font-medium  dark:text-gray-900 px-6 py-4 text-left select_search">collection</th>       
                        <th scope="col" class="text-sm font-medium  dark:text-gray-900 px-6 py-4 text-left"></th>
                        <th scope="col" class="text-sm font-medium  dark:text-gray-900 px-6 py-4 text-left"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $borrowed_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($book->borrowed_at); ?></td>
                            <td><?php echo e($book->title); ?></td>
                            <td><?php echo e($book->author); ?></td>
                            <td><?php echo e($book->published); ?></td>
                            <td><?php echo e($book->collection); ?></td>
                            <td><?php echo e($book->status); ?></td>

                            <td>
                            
                                <div class="sm:rounded-lg">
                                    <div class="max-w-xl">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'success','href' => '/borrowing_librarian/borrowed/books/view/'.e($book->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'success','href' => '/borrowing_librarian/borrowed/books/view/'.e($book->id).'']); ?>
                                            <i class="fa-solid fa-circle-info"></i>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> 
                                    
                                    </div>
                                </div>  
                        
                            </td> 
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
                <tfoot>
                    <tr>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">No.</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Borrowed Date</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Title</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Author</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Published</th>  
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">collection</th>       
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left">Status</th>
                        <th scope="col" class="text-sm font-medium  px-6 py-4 text-left"></th>
                    </tr>
                </tfoot>
            </table>
        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script>
           $(document).ready(function () {
                $('#table').DataTable({
                    initComplete: function () {
                        this.api()
                            .columns()
                            .every(function () {
                                var column = this;
                                if ($(column.header()).hasClass('select_search')) {

                                    var select = $('<select><option value=""></option></select>')
                                        .appendTo($(column.header()).empty())
                                        .on('change', function () {
                                            var val = $.fn.dataTable.util.escapeRegex(
                                                $(this).val()
                                            );
                                            column
                                                .search(val ? '^' + val + '$' : '', true, false)
                                                .draw();
                                        });
                                    column.data().unique().sort().each(function (d, j) {
                                        select.append('<option value="' + d + '">' + d + '</option>')
                                    });

                                }
                            });
                    },
                });
            });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal49832d77c192f71290736dce7e97696b24cee783)): ?>
<?php $component = $__componentOriginal49832d77c192f71290736dce7e97696b24cee783; ?>
<?php unset($__componentOriginal49832d77c192f71290736dce7e97696b24cee783); ?>
<?php endif; ?>

<style>
    .dataTables_wrapper .dataTables_length select {
        padding-right: 25px;
        font-weight: 900;
        background-color: #9d4edd;
        color: white;
    }
    tfoot input {
        width: 100%;
        padding: 3px;
        box-sizing: border-box;
    }
</style>

<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/borrowing_librarian/borrowed_books.blade.php ENDPATH**/ ?>