<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__("Book Borrow Transactions")); ?>

            </h2>


        </div>
     <?php $__env->endSlot(); ?>

    <script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>

    <div class="p-6 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <?php if($request_book->count() == 0): ?>
            <p>No transactions</p>
        <?php else: ?>
            <?php $__currentLoopData = $request_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($req->bookReqStatus == "APPROVED"): ?>
                    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
                        <p class="font-bold">Request status: <?php echo e($req->bookReqStatus); ?></p>
                        <p>Book title: <?php echo e($req->title); ?></p>
                        <p>Available pickup at (date and time): <?php echo e($req->avail_at); ?></p>
                        <p>Due date for the books to be returned (date and time): <?php echo e($req->due_at); ?></p>
                        <p>Request sent at: <?php echo e($req->created_at); ?></p>
                        <p>Request updated at: <?php echo e($req->updated_at); ?></p>
                    </div>
                <?php endif; ?>

                <?php if($req->bookReqStatus == "RELEASED"): ?>
                    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
                        <p class="font-bold">Request status: <?php echo e($req->bookReqStatus); ?></p>
                        <p>Book title: <?php echo e($req->title); ?></p>
                        <p>Important Notes:
                            <br>
                            Lost/Damaged Books = Replacement.
                            <br>
                           Over-due fine = Php 2.00/day per book
                        </p>
                        <p>Due date for the books to be returned (date and time): <?php echo e($req->due_at); ?></p>
                        <p>Request sent at: <?php echo e($req->created_at); ?></p>
                        <p>Request updated at: <?php echo e($req->updated_at); ?></p>
                    </div>
                <?php endif; ?>

                <?php if($req->bookReqStatus == "PENDING"): ?>
                    <div class="bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4" role="alert">
                        <p class="font-bold">Request status: <?php echo e($req->bookReqStatus); ?></p>
                        <p>Book title: <?php echo e($req->title); ?></p>
                        <p>Request sent at: <?php echo e($req->created_at); ?></p>
                        <p>Request updated at: <?php echo e($req->updated_at); ?></p>
                    </div>
                <?php endif; ?>

                <?php if($req->bookReqStatus == "DECLINED"): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                        <p class="font-bold">Request status: <?php echo e($req->bookReqStatus); ?></p>
                        <p>Book title: <?php echo e($req->title); ?></p>
                        <p>Request sent at: <?php echo e($req->created_at); ?></p>
                        <p>Request updated at: <?php echo e($req->updated_at); ?></p>
                    </div>
                <?php endif; ?>

                <?php if($req->bookReqStatus == "CANCELLED"): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                        <p class="font-bold">Request status: <?php echo e($req->bookReqStatus); ?></p>
                        <p>Book title: <?php echo e($req->title); ?></p>
                        <p>Request sent at: <?php echo e($req->created_at); ?></p>
                        <p>Request updated at: <?php echo e($req->updated_at); ?></p>
                    </div>
                <?php endif; ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>

    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>


<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/trans_view.blade.php ENDPATH**/ ?>