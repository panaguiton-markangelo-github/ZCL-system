<?php if (isset($component)) { $__componentOriginal373f847efe2d4746c8474fe5c27cab2319699c7a = $component; } ?>
<?php $component = App\View\Components\HlibrarianLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('hlibrarian-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\HlibrarianLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" />
    <link rel="stylesheet" href="@sweetalert2/theme-material-ui/material-ui.css">

     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__("Events")); ?>

            </h2>


        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 mt-2 bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <div class="sm:rounded-lg">
            <div class="max-w-xl">
                <?php echo $__env->make('head_librarian.partials.add_event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div> 
        
        <br>
        <p>Note: You may also add an event by clicking a day in the calendar below.</p>
        
    </div>


    <div class="p-6 mt-2 bg-white rounded-md shadow-md dark:bg-dark-eval-1">
    
        <?php if(session('message')): ?> 
            <p
                x-data="{ show: true }"
                x-show="show"
                x-transition
                x-init="setTimeout(() => show = false, 2500)"
                class="text-sm text-green-600 dark:text-green-400 mb-2"
            >
                <?php echo e(__(session('message'))); ?>

            </p>
        <?php endif; ?>

        <?php if($errors->any()): ?>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p
                x-data="{ show: true }"
                x-show="show"
                x-transition
                x-init="setTimeout(() => show = false, 2500)"
                class="text-sm text-red-600 dark:text-red-400 mb-2"
            >
                <?php echo e($error); ?>

            </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
        
        <div id="calendar"></div>
    
    </div>

    

    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.3/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>
    
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    
    <script>
      $(document).ready(function () {
          $.ajaxSetup({
              headers:{
                  'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
              }
          });
  
          var calendar = $('#calendar').fullCalendar({
            editable:true,
            timeZone: 'Asia/Manila',
            allDay:true,
            initialView: 'listWeek',
            views: {
                listDay: { buttonText: 'list day' },
                listWeek: { buttonText: 'list week' },
                listMonth: { buttonText: 'list month' }
            },
            header:{
                left:'prev,next,today',
                center:'title',
                right:'month,agendaWeek,agendaDay,listWeek,listMonth'
            },
            events:'/head_librarian/events',
            selectable:true,
            selectHelper:true,
            select: async function(start, end, allDay)
            {   
                const { value: title } = await Swal.fire({
                    title: 'Create an event',
                    input: 'text',
                    inputLabel: 'Event Title (The date will be what you have clicked!): ',
                    inputPlaceholder: 'Enter the event title',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Confirm',
                    inputValidator: (value) => {
                        if (!value) {
                            return 'You need to enter some title!'
                        }
                    }
                })

                if(title)
                {
                    var start = $.fullCalendar.formatDate(start, 'Y-MM-DD HH:mm:ss');

                    var end = $.fullCalendar.formatDate(end, 'Y-MM-DD HH:mm:ss');

                    $.ajax({
                        url:"/head_librarian/add/event",
                        type:"POST",
                        data:{
                            title: title,
                            start: start,
                            end: end,
                            type: 'add'
                        },
                        success:function(data)
                        {
                            calendar.fullCalendar('refetchEvents');
                            Swal.fire(
                                'Created!',
                                'The event was successfully created!.',
                                'success'
                            )
                            
                        }
                    })
                }
            },
            editable:true,
            eventResize: function(event, delta)
            {
                var start = $.fullCalendar.formatDate(event.start, 'Y-MM-DD HH:mm:ss');
                var end = $.fullCalendar.formatDate(event.end, 'Y-MM-DD HH:mm:ss');
                var title = event.title;
                var id = event.id;
                $.ajax({
                    url:"/head_librarian/update/event",
                    type:"POST",
                    data:{
                        title: title,
                        start: start,
                        end: end,
                        id: id,
                        type: 'update'
                    },
                    success:function(response)
                    {
                        calendar.fullCalendar('refetchEvents');
                        Swal.fire(
                            'Updated!',
                            'The event was updated successfully!',
                            'success'
                        )
                    }
                })
            },
            eventDrop: function(event, delta)
            {
                var start = $.fullCalendar.formatDate(event.start, 'Y-MM-DD HH:mm:ss');
                var end = $.fullCalendar.formatDate(event.end, 'Y-MM-DD HH:mm:ss');
                var title = event.title;
                var id = event.id;
                $.ajax({
                    url:"/head_librarian/update/event",
                    type:"POST",
                    data:{
                        title: title,
                        start: start,
                        end: end,
                        id: id,
                        type: 'update'
                    },
                    success:function(response)
                    {
                        calendar.fullCalendar('refetchEvents');
                        Swal.fire(
                            'Updated!',
                            'The event was updated successfully!',
                            'success'
                        )
                    }
                })
            },

            eventClick:function(event)
            {

                Swal.fire({
                    title: 'Are you sure?',
                    text: "This will permanently delete the event!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        var id = event.id;
                        $.ajax({
                            url:"/head_librarian/delete/event",
                            type:"POST",
                            data:{
                                id:id,
                                type:"delete"
                            },
                            success:function(response)
                            {
                                calendar.fullCalendar('refetchEvents');
                                Swal.fire(
                                    'Deleted!',
                                    'The event was successfully deleted!.',
                                    'success'
                                )
                            }
                        })
                        
                    }
                })
                
                // if(confirm("Are you sure you want to remove it?"))
                // {
                //     var id = event.id;
                //     $.ajax({
                //         url:"/head_librarian/delete/event",
                //         type:"POST",
                //         data:{
                //             id:id,
                //             type:"delete"
                //         },
                //         success:function(response)
                //         {
                //             calendar.fullCalendar('refetchEvents');
                //             alert("Event Deleted Successfully");
                //         }
                //     })
                // }
            }

          });
      });
  </script>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal373f847efe2d4746c8474fe5c27cab2319699c7a)): ?>
<?php $component = $__componentOriginal373f847efe2d4746c8474fe5c27cab2319699c7a; ?>
<?php unset($__componentOriginal373f847efe2d4746c8474fe5c27cab2319699c7a); ?>
<?php endif; ?>

<style>
    tfoot input {
        width: 100%;
        padding: 3px;
        box-sizing: border-box;
    }
</style>

<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/head_librarian/events.blade.php ENDPATH**/ ?>