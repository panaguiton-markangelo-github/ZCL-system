<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold leading-tight">
                <?php echo e(__("Borrower Card Details")); ?>

            </h2>

           

        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-6 mt-2 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
        <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
            Note: In this page, your membership card details are shown. You can choose to start edit your details by clicking the "edit" button below.
        </p>
    </div>


    <div class="p-6 mt-2 overflow-hidden bg-white rounded-md shadow-md dark:bg-dark-eval-1">
       
        <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
            <?php echo e(__('Borrower Card Information')); ?>

        </p>

        <br>
        <hr>

        <div class="grid grid-cols-4 gap-4 text-center">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('First Name: ')); ?> <?php echo e($member[0]->firstName); ?> 
                </p>
            </div>
            
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Last Name: ')); ?> <?php echo e($member[0]->lastName); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Email: ')); ?> <?php echo e($member[0]->email); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Phone: ')); ?> <?php echo e($member[0]->phone); ?> 
                </p>

            </div>

           
        </div>

        <br>

        <div class="grid grid-cols-4 gap-4 text-center">
            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Address: ')); ?> <?php echo e($member[0]->address); ?> 
                </p>
            </div>
            
            <div>
                <?php if($member[0]->type == '0'): ?>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Borrower Type: ')); ?> <?php echo e(__('NON-LGU')); ?> 
                    </p>
                <?php endif; ?>

                <?php if($member[0]->type == '1'): ?>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Borrower Type: ')); ?> <?php echo e(__('LGU')); ?> 
                    </p>
                 <?php endif; ?>

                 <?php if($member[0]->type == '2'): ?>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Borrower Type: ')); ?> <?php echo e(__('RECOMMENDED')); ?> 
                    </p>
                 <?php endif; ?>
               

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('ID card: ')); ?> <?php echo e($member[0]->id_card); ?> 
                </p>

            </div>

            <div>
                <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                    <?php echo e(__('Status: ')); ?> <?php echo e($member[0]->status); ?> 
                </p>

            </div>

           
        </div>

        <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
            <?php echo e(__('ID card (image): ')); ?>

        </p>
        <div class="mt-2 flex justify-start">
            <img class="border-solid border-4 border-red-500" src="<?php echo e(asset('storage/'.$member[0]->b_image)); ?>" alt="none" width="200" height="200">
        </div>

        <?php if($is_prof->count()): ?>

            <br>

            <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
                <?php echo e(__('Profession Information')); ?>

            </p>
    
            <br>
            <hr>

            <div class="grid grid-cols-4 gap-4 text-center">

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Position: ')); ?> <?php echo e($is_prof[0]->position); ?> 
                    </p>
                </div>
                
                <div>
                
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Office: ')); ?>  <?php echo e($is_prof[0]->office); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Office Address: ')); ?> <?php echo e($is_prof[0]->office_address); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Telephone No. (Work): ')); ?> <?php echo e($is_prof[0]->tel_no_work); ?> 
                    </p>
                </div>

            
            </div>

        <?php endif; ?>

        <?php if($is_stud->count()): ?>

            <br>

            <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
                <?php echo e(__('Student Information')); ?>

            </p>
    
            <br>
            <hr>

            <div class="grid grid-cols-4 gap-4 text-center">

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('School: ')); ?> <?php echo e($is_stud[0]->school); ?> 
                    </p>
                </div>
                
                <div>
                
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Out of School: ')); ?>  <?php echo e($is_stud[0]->out_of_school); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('School Level: ')); ?> <?php echo e($is_stud[0]->school_level); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Grade/Year Level: ')); ?> <?php echo e($is_stud[0]->grade_year_level); ?> 
                    </p>
                </div>

            
            </div>

        <?php endif; ?>

        <?php if($is_rec->count()): ?>

            <br>

            <p class="mt-1 font-bold text-xl text-gray-600 dark:text-gray-400 text-center">
                <?php echo e(__('Recommended Information')); ?>

            </p>
    
            <br>
            <hr>

            <div class="grid grid-cols-4 gap-4 text-center">

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Recommended by: ')); ?> <?php echo e($is_rec[0]->rec_by); ?> 
                    </p>
                </div>
                
                <div>
                
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Position: ')); ?>  <?php echo e($is_rec[0]->rec_by_position); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Office: ')); ?> <?php echo e($is_rec[0]->rec_by_office); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Office Address: ')); ?> <?php echo e($is_rec[0]->rec_by_office_address); ?> 
                    </p>
                </div>

            
            </div>

            <br>

            <div class="grid grid-cols-3 gap-3 text-center">

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Home Adress: ')); ?> <?php echo e($is_rec[0]->rec_by_home_address); ?> 
                    </p>
                </div>
                
                <div>
                
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Telephone No. (Work): ')); ?>  <?php echo e($is_rec[0]->rec_by_tel_no_work); ?> 
                    </p>

                </div>

                <div>
                    <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                        <?php echo e(__('Cellphone No.: ')); ?> <?php echo e($is_rec[0]->rec_by_cel_no); ?> 
                    </p>

                </div>
            
            </div>

            <p class="mt-2 text-md text-gray-600 dark:text-gray-400">
                <?php echo e(__('ID card (image): ')); ?>

            </p>
            <div class="mt-2 flex justify-start">
                <img class="border-solid border-4 border-red-500" src="<?php echo e(asset('storage/'.$is_rec[0]->r_image)); ?>" alt="none" width="200" height="200">
            </div>

        <?php endif; ?>

        
        <form method="POST" action="<?php echo e(route('borrower.edit')); ?>">
            <input name="user_id" type="number" value="<?php echo e($member[0]->id); ?>" hidden readonly>
            <?php echo csrf_field(); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['variant' => 'danger','class' => 'justify-center mt-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'danger','class' => 'justify-center mt-5']); ?>
                <?php echo e(__('Edit')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </form>
            
       
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>


<?php /**PATH C:\Users\drene\Documents\ZCL-system_GITHUB\ZCL-system\resources\views/view_borrower_card.blade.php ENDPATH**/ ?>